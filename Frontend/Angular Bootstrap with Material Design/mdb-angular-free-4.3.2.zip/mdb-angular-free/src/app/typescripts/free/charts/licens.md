https://github.com/valor-software/ng2-charts/blob/development/LICENSE
https://github.com/chartjs/Chart.js/blob/master/LICENSE.md
https://github.com/rendro/easy-pie-chart/blob/master/LICENSE
https://www.npmjs.com/package/ng2modules-easypiechart

